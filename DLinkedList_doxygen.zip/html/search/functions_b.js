var searchData=
[
  ['takefirst_51',['takeFirst',['../class_d_linked_list.html#a4e0cf026a13662b7b1efd47768abab95',1,'DLinkedList']]],
  ['takelast_52',['takeLast',['../class_d_linked_list.html#a456add780078106d58ac323fb9e20b37',1,'DLinkedList']]]
];
