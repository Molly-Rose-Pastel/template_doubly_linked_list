var searchData=
[
  ['previous_56',['previous',['../class_d_node.html#a2733fb9bad21340e68459cb91cbc45f9',1,'DNode']]]
];
