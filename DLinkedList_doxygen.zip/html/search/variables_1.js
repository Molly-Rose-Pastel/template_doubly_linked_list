var searchData=
[
  ['next_55',['next',['../class_d_node.html#a88feecc8cc64c4fd19108a1e3ae350fb',1,'DNode']]]
];
