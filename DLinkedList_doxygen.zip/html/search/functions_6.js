var searchData=
[
  ['last_41',['last',['../class_d_linked_list.html#ab066bd462397247dfe4b9cd18ef00e97',1,'DLinkedList']]]
];
