var files_dup =
[
    [ "DLinkedList.h", "_d_linked_list_8h.html", [
      [ "DNode", "class_d_node.html", "class_d_node" ],
      [ "DLinkedList", "class_d_linked_list.html", "class_d_linked_list" ]
    ] ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ]
];