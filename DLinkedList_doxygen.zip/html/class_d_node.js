var class_d_node =
[
    [ "item", "class_d_node.html#a1b09de1e9a118c0c40fe28b9240865a5", null ],
    [ "next", "class_d_node.html#a88feecc8cc64c4fd19108a1e3ae350fb", null ],
    [ "previous", "class_d_node.html#a2733fb9bad21340e68459cb91cbc45f9", null ]
];